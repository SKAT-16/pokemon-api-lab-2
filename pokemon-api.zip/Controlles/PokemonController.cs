using Microsoft.AspNetCore.Mvc;
using pokemon_api.Models;
using PokemonApi.Services;

namespace PokemonApi.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class PokemonController : ControllerBase
  {
    private readonly IPokemonService _pokemonService;

    public PokemonController(IPokemonService pokemonService)
    {
      _pokemonService = pokemonService;
    }

    [HttpGet]
    public ActionResult<IEnumerable<Pokemon>> GetAll()
    {
      var pokemons = _pokemonService.GetAll();
      if (!pokemons.Any())
        return NotFound("No Pokémon found.");

      return Ok(pokemons);
    }

    [HttpGet("{id}")]
    public ActionResult<Pokemon> GetByID(string id)
    {
      var pokemon = _pokemonService.GetById(id);
      if (pokemon == null)
        return NotFound($"No Pokémon found with ID {id}.");

      return Ok(pokemon);
    }

    [HttpPost]
    public ActionResult<Pokemon> AddPokemon([FromBody] Pokemon pokemon)
    {
      try
      {
        _pokemonService.AddPokemon(pokemon);

        return CreatedAtAction(nameof(GetByID), new { id = pokemon.Id }, pokemon);
      }
      catch (ArgumentException ex)
      {
        return Conflict(ex.Message);
      }
    }

    [HttpPut("{id}")]
    public ActionResult UpdatePokemon(string id, [FromBody] Pokemon updatedPokemon)
    {
      try
      {
        _pokemonService.UpdatePokemon(id, updatedPokemon);
        return NoContent();
      }
      catch (KeyNotFoundException ex)
      {
        return NotFound(ex.Message);
      }
    }

    [HttpDelete("{id}")]
    public ActionResult DeletePokemon(string id)
    {
      try
      {
        _pokemonService.DeletePokemon(id);
        return NoContent();
      }
      catch (KeyNotFoundException ex)
      {
        return NotFound(ex.Message);
      }
    }
  }
}
