using System.Collections.Generic;
using MongoDB.Driver;
using pokemon_api.Models;

namespace PokemonApi.Services
{
  public interface IPokemonService
  {
    IEnumerable<Pokemon> GetAll();
    Pokemon GetById(string id);
    void AddPokemon(Pokemon pokemon);
    void UpdatePokemon(string id, Pokemon updatedPokemon);
    void DeletePokemon(string id);
  }

  public class PokemonService : IPokemonService
  {
    private readonly IMongoCollection<Pokemon> _pokemonCollection;
    private static List<Pokemon> _pokemons = new List<Pokemon>();

    public PokemonService(IConfiguration config)
    {
      var client = new MongoClient(config["MongoDbSettings:ConnectionString"]);
      var database = client.GetDatabase(config["MongoDbSettings:DatabaseName"]);

      _pokemonCollection = database.GetCollection<Pokemon>(config["MongoDbSettings:CollectionName"]);
    }

    public IEnumerable<Pokemon> GetAll()
    {
      return _pokemonCollection.Find<Pokemon>(_ => true).ToList<Pokemon>();
    }

    public Pokemon GetById(string id)
    {
      return _pokemonCollection.Find<Pokemon>(p => p.Id == id).FirstOrDefault();
    }

    public void AddPokemon(Pokemon pokemon)
    {
      _pokemonCollection.InsertOne(pokemon);
    }

    public void UpdatePokemon(string id, Pokemon updatedPokemon)
    {
      var filter = Builders<Pokemon>.Filter.Eq(p => p.Id, id);
      var update = Builders<Pokemon>.Update
        .Set(p => p.Name, updatedPokemon.Name)
        .Set(p => p.Type, updatedPokemon.Type)
        .Set(p => p.Ability, updatedPokemon.Ability)
        .Set(p => p.Level, updatedPokemon.Level);


      _pokemonCollection.UpdateOne(filter, update);
    }

    public void DeletePokemon(string id)
    {
      var pokemon = _pokemonCollection.Find(p => p.Id == id).FirstOrDefault();
      if (pokemon == null)
        throw new KeyNotFoundException($"No Pokémon found with ID {id}.");

      _pokemonCollection.DeleteOne(p => p.Id == id);
    }
  }
}
